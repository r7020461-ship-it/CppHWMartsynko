# Cross-platform Client-Server Chat with File Transfer

## Що вміє програма

- сервер приймає багато клієнтів одночасно;
- кожен клієнт отримує свій ID;
- клієнти можуть надсилати одне одному текстові повідомлення;
- клієнти можуть надсилати одне одному файли;
- отримані файли зберігаються у папку `downloads`;
- сервер веде лог у `server.log`.

## Збірка на Linux

У терміналі в папці проєкту:

```bash
mkdir build
cd build
cmake ..
cmake --build .
```

## Запуск на Linux

Термінал 1:

```bash
./server
```

Термінал 2:

```bash
./client
```

Термінал 3:

```bash
./client
```

## Команди клієнта

```text
/help
/clients
/msg <client_id> <text>
<client_id> <text>
/file <client_id> <path>
/quit
```

## Приклад повідомлення

Якщо перший клієнт має ID `1`, а другий має ID `2`, тоді у клієнта 1:

```text
/msg 2 Hello
```

Або коротко:

```text
2 Hello
```

## Приклад надсилання файлу

```text
/file 2 README.md
```

У клієнта 2 файл збережеться у папку:

```text
downloads/README.md
```

Якщо файл з такою назвою вже існує, програма створить назву типу `README_1.md`.

## Запуск з іншим портом

Сервер:

```bash
./server 55000
```

Клієнт:

```bash
./client 127.0.0.1 55000
```

Для передачі файлів використовується простий протокол:

```text
FILE <target_id> <filename_size> <file_size>\n
<filename bytes>
<file bytes>
```

Для текстових повідомлень:

```text
MSG <target_id> <message_size>\n
<message bytes>
```

