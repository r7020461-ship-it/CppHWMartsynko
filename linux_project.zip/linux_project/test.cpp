/*
 * test.cpp
 * Автори: Марцинко Руслана та Термус Євгенія
 * Група: Статистика 1
 */

#include <iostream>

int main() {
    std::cout << "Manual test plan:\n";
    std::cout << "1. Build the project with CMake.\n";
    std::cout << "2. Run ./server in one terminal.\n";
    std::cout << "3. Run ./client in two other terminals.\n";
    std::cout << "4. Send a text message: /msg 2 hello\n";
    std::cout << "5. Send a file: /file 2 README.md\n";
    std::cout << "6. Check the receiver's downloads folder.\n";
    return 0;
}
