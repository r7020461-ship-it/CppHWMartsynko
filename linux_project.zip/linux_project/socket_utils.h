#ifndef SOCKET_UTILS_H
#define SOCKET_UTILS_H

#include <cstddef>
#include <cstdint>
#include <cstring>
#include <string>

#ifdef _WIN32
    #ifndef NOMINMAX
    #define NOMINMAX
    #endif
    #define _WINSOCK_DEPRECATED_NO_WARNINGS
    #include <winsock2.h>
    #include <ws2tcpip.h>
    using socket_t = SOCKET;
#else
    #include <arpa/inet.h>
    #include <cerrno>
    #include <csignal>
    #include <netinet/in.h>
    #include <sys/socket.h>
    #include <unistd.h>
    using socket_t = int;
    constexpr socket_t INVALID_SOCKET = -1;
    constexpr int SOCKET_ERROR = -1;
#endif

inline bool initSockets() {
#ifdef _WIN32
    WSADATA wsaData{};
    return WSAStartup(MAKEWORD(2, 2), &wsaData) == 0;
#else
    signal(SIGPIPE, SIG_IGN);
    return true;
#endif
}

inline void cleanupSockets() {
#ifdef _WIN32
    WSACleanup();
#endif
}

inline void closeSocket(socket_t sock) {
#ifdef _WIN32
    closesocket(sock);
#else
    close(sock);
#endif
}

inline std::string socketError() {
#ifdef _WIN32
    return "WSA error: " + std::to_string(WSAGetLastError());
#else
    return std::strerror(errno);
#endif
}

inline bool sendAll(socket_t sock, const char* data, std::size_t size) {
    std::size_t sentTotal = 0;
    while (sentTotal < size) {
        std::size_t remaining = size - sentTotal;
#ifdef _WIN32
        int chunk = remaining > 65536 ? 65536 : static_cast<int>(remaining);
        int sent = send(sock, data + sentTotal, chunk, 0);
#else
        ssize_t sent = send(sock, data + sentTotal, remaining, 0);
#endif
        if (sent <= 0) {
            return false;
        }
        sentTotal += static_cast<std::size_t>(sent);
    }
    return true;
}

inline bool sendString(socket_t sock, const std::string& text) {
    return sendAll(sock, text.data(), text.size());
}

inline bool recvExact(socket_t sock, char* buffer, std::size_t size) {
    std::size_t receivedTotal = 0;
    while (receivedTotal < size) {
        std::size_t remaining = size - receivedTotal;
#ifdef _WIN32
        int chunk = remaining > 65536 ? 65536 : static_cast<int>(remaining);
        int received = recv(sock, buffer + receivedTotal, chunk, 0);
#else
        ssize_t received = recv(sock, buffer + receivedTotal, remaining, 0);
#endif
        if (received <= 0) {
            return false;
        }
        receivedTotal += static_cast<std::size_t>(received);
    }
    return true;
}

inline bool recvString(socket_t sock, std::string& out, std::size_t size) {
    out.assign(size, '\0');
    if (size == 0) {
        return true;
    }
    return recvExact(sock, out.data(), size);
}

inline bool recvLine(socket_t sock, std::string& line) {
    line.clear();
    char ch = 0;
    while (true) {
#ifdef _WIN32
        int received = recv(sock, &ch, 1, 0);
#else
        ssize_t received = recv(sock, &ch, 1, 0);
#endif
        if (received <= 0) {
            return false;
        }
        if (ch == '\n') {
            return true;
        }
        if (ch != '\r') {
            line.push_back(ch);
        }
        if (line.size() > 8192) {
            return false;
        }
    }
}

#endif
