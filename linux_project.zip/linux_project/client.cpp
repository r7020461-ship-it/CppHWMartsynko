/*
 * client.cpp
 * Автори: Марцинко Руслана та Термус Євгенія
 * Група: Статистика 1
 * Опис:
 * Цей файл реалізує клієнтську частину програми для обміну повідомленнями.
 */

#include "socket_utils.h"

#include <atomic>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

using namespace std;
namespace fs = std::filesystem;

mutex sendMutex;
atomic<bool> running{true};

string safeFileName(string name) {
    for (char& ch : name) {
        if (ch == '/' || ch == '\\' || ch == ':' || ch == '*' || ch == '?' || ch == '"' || ch == '<' || ch == '>' || ch == '|') {
            ch = '_';
        }
    }
    if (name.empty()) {
        name = "received_file";
    }
    return name;
}

fs::path uniqueDownloadPath(const string& filename) {
    fs::create_directories("downloads");
    fs::path base = fs::path("downloads") / safeFileName(filename);
    if (!fs::exists(base)) {
        return base;
    }

    string stem = base.stem().string();
    string ext = base.extension().string();
    for (int i = 1; i < 10000; ++i) {
        fs::path candidate = fs::path("downloads") / (stem + "_" + to_string(i) + ext);
        if (!fs::exists(candidate)) {
            return candidate;
        }
    }
    return fs::path("downloads") / (stem + "_copy" + ext);
}

bool sendPacket(socket_t socket, const string& header, const string& payload = "") {
    lock_guard<mutex> lock(sendMutex);
    if (!sendString(socket, header)) {
        return false;
    }
    if (!payload.empty() && !sendString(socket, payload)) {
        return false;
    }
    return true;
}

bool sendMessage(socket_t socket, int targetId, const string& text) {
    string header = "MSG " + to_string(targetId) + " " + to_string(text.size()) + "\n";
    return sendPacket(socket, header, text);
}

bool sendFile(socket_t socket, int targetId, const fs::path& path) {
    if (!fs::exists(path) || !fs::is_regular_file(path)) {
        cout << "File not found: " << path.string() << endl;
        return false;
    }

    uint64_t fileSize = static_cast<uint64_t>(fs::file_size(path));
    string filename = path.filename().string();
    string header = "FILE " + to_string(targetId) + " " + to_string(filename.size()) + " " + to_string(fileSize) + "\n";

    ifstream file(path, ios::binary);
    if (!file) {
        cout << "Cannot open file: " << path.string() << endl;
        return false;
    }

    lock_guard<mutex> lock(sendMutex);
    if (!sendString(socket, header) || !sendString(socket, filename)) {
        return false;
    }

    vector<char> buffer(64 * 1024);
    while (file) {
        file.read(buffer.data(), static_cast<streamsize>(buffer.size()));
        streamsize count = file.gcount();
        if (count > 0 && !sendAll(socket, buffer.data(), static_cast<size_t>(count))) {
            return false;
        }
    }
    return true;
}

void receiveLoop(socket_t socket) {
    string line;
    while (running && recvLine(socket, line)) {
        stringstream ss(line);
        string command;
        ss >> command;

        if (command == "ID") {
            int id = 0;
            ss >> id;
            cout << "\nYour client ID is " << id << endl;
        } else if (command == "CLIENTS") {
            uint64_t size = 0;
            ss >> size;
            string list;
            if (!ss || !recvString(socket, list, static_cast<size_t>(size))) break;
            cout << "\nConnected clients: " << (list.empty() ? "none" : list) << endl;
        } else if (command == "INFO" || command == "ERROR") {
            uint64_t size = 0;
            ss >> size;
            string text;
            if (!ss || !recvString(socket, text, static_cast<size_t>(size))) break;
            cout << "\n" << command << ": " << text << endl;
        } else if (command == "MSG") {
            int fromId = 0;
            uint64_t size = 0;
            ss >> fromId >> size;
            string text;
            if (!ss || !recvString(socket, text, static_cast<size_t>(size))) break;
            cout << "\nMessage from client " << fromId << ": " << text << endl;
        } else if (command == "FILE") {
            int fromId = 0;
            uint64_t filenameSize = 0;
            uint64_t fileSize = 0;
            ss >> fromId >> filenameSize >> fileSize;

            if (!ss || filenameSize == 0 || filenameSize > 4096) {
                cout << "\nInvalid file packet." << endl;
                break;
            }

            string filename;
            if (!recvString(socket, filename, static_cast<size_t>(filenameSize))) break;

            fs::path savePath = uniqueDownloadPath(filename);
            ofstream out(savePath, ios::binary);
            if (!out) {
                cout << "\nCannot save file: " << savePath.string() << endl;
                break;
            }

            vector<char> buffer(64 * 1024);
            uint64_t remaining = fileSize;
            while (remaining > 0) {
                size_t chunk = static_cast<size_t>(min<uint64_t>(remaining, buffer.size()));
                if (!recvExact(socket, buffer.data(), chunk)) {
                    running = false;
                    return;
                }
                out.write(buffer.data(), static_cast<streamsize>(chunk));
                remaining -= chunk;
            }

            cout << "\nFile from client " << fromId << " saved as: " << savePath.string() << endl;
        } else {
            cout << "\nUnknown server packet: " << line << endl;
        }
    }

    running = false;
    cout << "\nDisconnected from server." << endl;
}

void printHelp() {
    cout << "\nCommands:\n";
    cout << "  /msg <client_id> <text>      send text message\n";
    cout << "  <client_id> <text>           short form for text message\n";
    cout << "  /file <client_id> <path>     send file\n";
    cout << "  /clients                     show connected clients\n";
    cout << "  /help                        show help\n";
    cout << "  /quit                        exit\n";
}

int main(int argc, char* argv[]) {
    string host = "127.0.0.1";
    int port = 54000;

    if (argc >= 2) host = argv[1];
    if (argc >= 3) port = stoi(argv[2]);

    if (!initSockets()) {
        cerr << "Failed to initialize sockets." << endl;
        return 1;
    }

    socket_t clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == INVALID_SOCKET) {
        cerr << "Failed to create socket: " << socketError() << endl;
        cleanupSockets();
        return 1;
    }

    sockaddr_in serverAddress{};
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(static_cast<uint16_t>(port));

    if (inet_pton(AF_INET, host.c_str(), &serverAddress.sin_addr) <= 0) {
        cerr << "Invalid server address: " << host << endl;
        closeSocket(clientSocket);
        cleanupSockets();
        return 1;
    }

    if (connect(clientSocket, reinterpret_cast<sockaddr*>(&serverAddress), sizeof(serverAddress)) == SOCKET_ERROR) {
        cerr << "Failed to connect to server: " << socketError() << endl;
        closeSocket(clientSocket);
        cleanupSockets();
        return 1;
    }

    cout << "Connected to server " << host << ":" << port << endl;
    printHelp();

    thread receiver(receiveLoop, clientSocket);

    string input;
    while (running && getline(cin, input)) {
        if (input.empty()) continue;

        if (input == "/help") {
            printHelp();
        } else if (input == "/clients") {
            sendPacket(clientSocket, "LIST\n");
        } else if (input == "/quit") {
            sendPacket(clientSocket, "QUIT\n");
            running = false;
            break;
        } else if (input.rfind("/msg ", 0) == 0) {
            stringstream ss(input.substr(5));
            int targetId = 0;
            ss >> targetId;
            string text;
            getline(ss, text);
            if (!text.empty() && text[0] == ' ') text.erase(0, 1);
            if (targetId <= 0 || text.empty()) {
                cout << "Usage: /msg <client_id> <text>" << endl;
            } else if (!sendMessage(clientSocket, targetId, text)) {
                cout << "Failed to send message." << endl;
                running = false;
            }
        } else if (input.rfind("/file ", 0) == 0) {
            stringstream ss(input.substr(6));
            int targetId = 0;
            ss >> targetId;
            string pathText;
            getline(ss, pathText);
            if (!pathText.empty() && pathText[0] == ' ') pathText.erase(0, 1);
            if (targetId <= 0 || pathText.empty()) {
                cout << "Usage: /file <client_id> <path>" << endl;
            } else if (!sendFile(clientSocket, targetId, fs::path(pathText))) {
                cout << "Failed to send file." << endl;
            }
        } else {
            stringstream ss(input);
            int targetId = 0;
            ss >> targetId;
            string text;
            getline(ss, text);
            if (!text.empty() && text[0] == ' ') text.erase(0, 1);
            if (targetId <= 0 || text.empty()) {
                cout << "Unknown command. Use /help." << endl;
            } else if (!sendMessage(clientSocket, targetId, text)) {
                cout << "Failed to send message." << endl;
                running = false;
            }
        }
    }

    running = false;
    closeSocket(clientSocket);
    if (receiver.joinable()) {
        receiver.join();
    }
    cleanupSockets();
    return 0;
}
