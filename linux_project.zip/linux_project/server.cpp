/*
 * server.cpp
 * Автори: Марцинко Руслана та Термус Євгенія
 * Група: Статистика 1
 * Опис:
 * Цей файл реалізує серверну частину програми для обміну повідомленнями між клієнтами.
 * Основні функціональні можливості:
 * 1. Обробка підключення клієнтів.
 * 2. Надсилання повідомлень між клієнтами.
 * 3. Логування подій у файл (server.log).
 * 4. Розсилка списку підключених клієнтів.
 */

#include "socket_utils.h"

#include <atomic>
#include <chrono>
#include <fstream>
#include <iostream>
#include <map>
#include <memory>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

using namespace std;

struct Client {
    socket_t socket;
    mutex sendMutex;
};

map<int, shared_ptr<Client>> clients;
mutex clientsMutex;
mutex logMutex;
ofstream logFile("server.log", ios::app);
atomic<int> nextClientId{1};

void logMessage(const string& message) {
    lock_guard<mutex> lock(logMutex);
    string line = message;
    logFile << line << endl;
    cout << line << endl;
}

shared_ptr<Client> getClient(int id) {
    lock_guard<mutex> lock(clientsMutex);
    auto it = clients.find(id);
    if (it == clients.end()) {
        return nullptr;
    }
    return it->second;
}

string buildClientList() {
    lock_guard<mutex> lock(clientsMutex);
    stringstream ss;
    bool first = true;
    for (const auto& [id, client] : clients) {
        if (!first) ss << ' ';
        ss << id;
        first = false;
    }
    return ss.str();
}

bool sendPacket(const shared_ptr<Client>& client, const string& header, const string& payload = "") {
    lock_guard<mutex> lock(client->sendMutex);
    if (!sendString(client->socket, header)) {
        return false;
    }
    if (!payload.empty() && !sendString(client->socket, payload)) {
        return false;
    }
    return true;
}

void sendInfo(const shared_ptr<Client>& client, const string& text) {
    sendPacket(client, "INFO " + to_string(text.size()) + "\n", text);
}

void sendError(const shared_ptr<Client>& client, const string& text) {
    sendPacket(client, "ERROR " + to_string(text.size()) + "\n", text);
}

void sendClientListTo(const shared_ptr<Client>& client) {
    string list = buildClientList();
    sendPacket(client, "CLIENTS " + to_string(list.size()) + "\n", list);
}

void broadcastClientList() {
    vector<shared_ptr<Client>> snapshot;
    {
        lock_guard<mutex> lock(clientsMutex);
        for (const auto& [id, client] : clients) {
            snapshot.push_back(client);
        }
    }

    string list = buildClientList();
    for (const auto& client : snapshot) {
        sendPacket(client, "CLIENTS " + to_string(list.size()) + "\n", list);
    }
}

void drainBytes(socket_t socket, uint64_t count) {
    vector<char> buffer(64 * 1024);
    uint64_t remaining = count;
    while (remaining > 0) {
        size_t chunk = static_cast<size_t>(min<uint64_t>(remaining, buffer.size()));
        if (!recvExact(socket, buffer.data(), chunk)) {
            return;
        }
        remaining -= chunk;
    }
}

bool forwardFile(int senderId, socket_t senderSocket, const shared_ptr<Client>& receiver,
                 const string& filename, uint64_t fileSize) {
    lock_guard<mutex> lock(receiver->sendMutex);

    string header = "FILE " + to_string(senderId) + " " + to_string(filename.size()) + " " + to_string(fileSize) + "\n";
    if (!sendString(receiver->socket, header)) {
        drainBytes(senderSocket, fileSize);
        return false;
    }
    if (!sendString(receiver->socket, filename)) {
        drainBytes(senderSocket, fileSize);
        return false;
    }

    vector<char> buffer(64 * 1024);
    uint64_t remaining = fileSize;
    while (remaining > 0) {
        size_t chunk = static_cast<size_t>(min<uint64_t>(remaining, buffer.size()));
        if (!recvExact(senderSocket, buffer.data(), chunk)) {
            return false;
        }
        if (!sendAll(receiver->socket, buffer.data(), chunk)) {
            drainBytes(senderSocket, remaining - chunk);
            return false;
        }
        remaining -= chunk;
    }
    return true;
}

void handleClient(int clientId, shared_ptr<Client> client) {
    sendPacket(client, "ID " + to_string(clientId) + "\n");
    sendInfo(client, "Connected. Your client ID is " + to_string(clientId) + ". Use /help in the client.");
    broadcastClientList();

    string line;
    while (recvLine(client->socket, line)) {
        stringstream ss(line);
        string command;
        ss >> command;

        if (command == "MSG") {
            int targetId = 0;
            uint64_t textSize = 0;
            ss >> targetId >> textSize;

            string text;
            if (!ss || !recvString(client->socket, text, static_cast<size_t>(textSize))) {
                sendError(client, "Invalid MSG packet.");
                break;
            }

            auto target = getClient(targetId);
            if (!target) {
                sendError(client, "Client " + to_string(targetId) + " not found.");
                continue;
            }

            string header = "MSG " + to_string(clientId) + " " + to_string(text.size()) + "\n";
            if (sendPacket(target, header, text)) {
                sendInfo(client, "Message sent to client " + to_string(targetId) + ".");
                logMessage("Client " + to_string(clientId) + " sent a message to client " + to_string(targetId) + ".");
            } else {
                sendError(client, "Failed to deliver message to client " + to_string(targetId) + ".");
            }
        } else if (command == "FILE") {
            int targetId = 0;
            uint64_t filenameSize = 0;
            uint64_t fileSize = 0;
            ss >> targetId >> filenameSize >> fileSize;

            if (!ss || filenameSize == 0 || filenameSize > 4096) {
                sendError(client, "Invalid FILE header.");
                break;
            }

            string filename;
            if (!recvString(client->socket, filename, static_cast<size_t>(filenameSize))) {
                sendError(client, "Cannot read file name.");
                break;
            }

            auto target = getClient(targetId);
            if (!target) {
                drainBytes(client->socket, fileSize);
                sendError(client, "Client " + to_string(targetId) + " not found. File was not sent.");
                continue;
            }

            bool ok = forwardFile(clientId, client->socket, target, filename, fileSize);
            if (ok) {
                sendInfo(client, "File sent to client " + to_string(targetId) + ": " + filename);
                logMessage("Client " + to_string(clientId) + " sent file '" + filename + "' to client " + to_string(targetId) + ".");
            } else {
                sendError(client, "File transfer failed.");
                break;
            }
        } else if (command == "LIST") {
            sendClientListTo(client);
        } else if (command == "QUIT") {
            break;
        } else {
            sendError(client, "Unknown command. Use MSG, FILE, LIST or QUIT.");
        }
    }

    {
        lock_guard<mutex> lock(clientsMutex);
        clients.erase(clientId);
    }
    closeSocket(client->socket);
    logMessage("Client " + to_string(clientId) + " disconnected.");
    broadcastClientList();
}

int main(int argc, char* argv[]) {
    int port = 54000;
    if (argc >= 2) {
        port = stoi(argv[1]);
    }

    if (!initSockets()) {
        cerr << "Failed to initialize sockets." << endl;
        return 1;
    }

    socket_t serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET) {
        cerr << "Failed to create server socket: " << socketError() << endl;
        cleanupSockets();
        return 1;
    }

    int opt = 1;
#ifdef _WIN32
    setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char*>(&opt), sizeof(opt));
#else
    setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
#endif

    sockaddr_in serverAddress{};
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = htonl(INADDR_ANY);
    serverAddress.sin_port = htons(static_cast<uint16_t>(port));

    if (bind(serverSocket, reinterpret_cast<sockaddr*>(&serverAddress), sizeof(serverAddress)) == SOCKET_ERROR) {
        cerr << "Bind failed: " << socketError() << endl;
        closeSocket(serverSocket);
        cleanupSockets();
        return 1;
    }

    if (listen(serverSocket, 16) == SOCKET_ERROR) {
        cerr << "Listen failed: " << socketError() << endl;
        closeSocket(serverSocket);
        cleanupSockets();
        return 1;
    }

    logMessage("Server started on port " + to_string(port) + ". Waiting for clients...");

    while (true) {
        sockaddr_in clientAddress{};
#ifdef _WIN32
        int clientSize = sizeof(clientAddress);
#else
        socklen_t clientSize = sizeof(clientAddress);
#endif
        socket_t clientSocket = accept(serverSocket, reinterpret_cast<sockaddr*>(&clientAddress), &clientSize);
        if (clientSocket == INVALID_SOCKET) {
            cerr << "Accept failed: " << socketError() << endl;
            continue;
        }

        int clientId = nextClientId++;
        auto client = make_shared<Client>();
        client->socket = clientSocket;

        {
            lock_guard<mutex> lock(clientsMutex);
            clients[clientId] = client;
        }

        logMessage("Client " + to_string(clientId) + " connected.");
        thread(handleClient, clientId, client).detach();
    }

    closeSocket(serverSocket);
    cleanupSockets();
    return 0;
}
